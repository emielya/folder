<?php
// Include the database connection file
include('../db_connection.php');

// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['staff_id'])) {
    header("Location: ../login.php"); // Redirect to login if not logged in
    exit();
}

$staff_id = $_SESSION['staff_id']; // Logged in staff ID

// Fetch the leave applications submitted by the staff
$query = "SELECT * FROM leave_applications WHERE staff_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $staff_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if there are any applications
if ($result->num_rows > 0) {
    $applications = $result->fetch_all(MYSQLI_ASSOC); // Fetch all applications
} else {
    $applications = [];
}

$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave Application Status</title>

    <!-- Add CSS styles -->
    <style>
        body {
		font-family: 'Arial', sans-serif;
		margin: 0;
		padding: 0;
		background: url(../imgs/section.jpg) no-repeat center center fixed;
		background-size: cover;
    color: #fff;
}

        .container {
            width: 60%;
            margin: 100px auto;
            padding: 40px;
            background: rgba(0, 0, 0, 0.7);
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
        }

        h1 {
            font-size: 32px;
            color: #cb4335 ;
            text-align: center;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #3498db;
            color: white;
        }

        tr:nth-child(even) {
            background-color:;
        }

        tr:hover {
            background-color: #000000;
        }

        .status {
            font-weight: bold;
        }

        .approved {
            color: green;
        }

        .pending {
            color: orange;
        }

        .rejected {
            color: red;
        }

       .home-button {
    background-color: #1c1e44;
    color: white;
    padding: 14px 24px;
    font-size: 18px;
    font-weight: bold;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    margin: 20px auto;
    display: block;
    width: fit-content;
    text-align: center;
    text-decoration: none; /* Remove underline */
}

	.home-button:hover {
		background-color: #000435;
}	
    </style>
</head>
<body>

    <!-- Main Container -->
    <div class="container">
        <h1>Leave Application Status</h1>

        <?php if (!empty($applications)): ?>
            <!-- Table to display leave applications -->
            <table>
                <thead>
                    <tr>
                        <th>Leave Type</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Reason</th>
                        <th>Supporting Document</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($applications as $application): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($application['leave_type']); ?></td>
                            <td><?php echo htmlspecialchars($application['start_date']); ?></td>
                            <td><?php echo htmlspecialchars($application['end_date']); ?></td>
                            <td><?php echo htmlspecialchars($application['reason']); ?></td>
                            <td>
                                <?php if ($application['supporting_document']): ?>
                                    <a href="<?php echo $application['supporting_document']; ?>" target="_blank">View Document</a>
                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </td>
                            <td class="status 
                                <?php echo strtolower($application['status']); ?>">
                                <?php echo htmlspecialchars($application['status']); ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No leave applications found.</p>
        <?php endif; ?>

        <!-- Back to Homepage Button -->
       <a href="../Staff/index.html" class="home-button">Back to Homepage</a>

    </div>

</body>
</html>
