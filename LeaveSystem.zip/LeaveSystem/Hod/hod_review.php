<?php
// Include the database connection and session management at the top
include('../db_connection.php');
session_start();

if (!isset($_SESSION['staff_id'])) {
    header("Location: ../login.php");
    exit();
}

// Fetch the logged-in staff details and the leave applications grouped by status
$staff_id = $_SESSION['staff_id'];
$query_hod = "SELECT department FROM staff WHERE staff_id = ?";
$stmt_hod = $conn->prepare($query_hod);
$stmt_hod->bind_param("i", $staff_id);
$stmt_hod->execute();
$result_hod = $stmt_hod->get_result();
$hod_data = $result_hod->fetch_assoc();

if (!$hod_data) {
    die("Access denied. Only HODs can access this page.");
}

$department = $hod_data['department'];

// Handle form submission for approving or rejecting leave applications
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['leave_id']) && isset($_POST['status'])) {
        $leave_id = $_POST['leave_id'];
        $status = $_POST['status'];

        // Update leave status in the database
        $update_query = "UPDATE leave_applications SET status = ? WHERE application_id = ?";
        $stmt_update = $conn->prepare($update_query);
        $stmt_update->bind_param("si", $status, $leave_id);
        $stmt_update->execute();

        // Redirect back to the page after update
        header("Location: hod_review.php");
        exit();
    }
}

// Base query to fetch all leave applications
$query_all = "SELECT la.*, s.name AS staff_name
              FROM leave_applications la
              JOIN staff s ON la.staff_id = s.staff_id";
$stmt_all = $conn->prepare($query_all);
$stmt_all->execute();
$result_all = $stmt_all->get_result();
$leave_applications = $result_all->fetch_all(MYSQLI_ASSOC);

// Close the statement
$stmt_all->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOD - Review Leave Applications</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #4c4c51;
            color: #333;
        }

        .container {
            width: 80%;
            margin: 50px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            font-size: 32px;
            color:#000000;
            text-align: center;
            margin-bottom: 30px;
        }

        .status-buttons {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .status-button {
            background-color: #b34f45 ;
            color: white;
            padding: 10px 20px;
            font-size: 18px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            margin: 0 10px;
        }

        .status-button:hover {
            background-color: #1c1e44;
        }

        .application-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #292a50;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .status {
            font-weight: bold;
        }

        .approved {
            color: green;
        }

        .pending {
            color: orange;
        }

        .rejected {
            color: red;
        }

       .home-button {
			background-color: #1c1e44;
			color: white;
			padding: 14px 24px;
			font-size: 18px;
			font-weight: bold;
			border: none;
			border-radius: 8px;
			cursor: pointer;
			margin: 20px auto;
			display: block;
			width: fit-content;
			text-align: center;
			text-decoration: none; /* Remove underline */
}

		.home-button:hover {
			background-color: #000435;
}

        .action-btns {
            display: flex;
            justify-content: space-around;
        }

        .action-btn {
            padding: 8px 16px;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
        }

        .approve-btn {
            background-color: #2ecc71;
            color: white;
        }

        .reject-btn {
            background-color: #e74c3c;
            color: white;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Review Leave Applications</h1>

    <!-- Status Buttons -->
    <div class="status-buttons">
        <button class="status-button" id="pending-btn">Pending</button>
        <button class="status-button" id="approved-btn">Approved</button>
        <button class="status-button" id="rejected-btn">Rejected</button>
    </div>

    <!-- Leave Applications (All status initially) -->
    <div id="leave-applications-container">
        <?php foreach (['pending', 'approved', 'rejected'] as $status): ?>
            <div class="status-section" id="<?php echo $status; ?>-applications" style="display: none;">
                <h2><?php echo ucfirst($status); ?> Applications</h2>
                <?php 
                // Filter applications by status
                $filtered_applications = array_filter($leave_applications, function($application) use ($status) {
                    return strtolower($application['status']) == $status;
                });

                if (!empty($filtered_applications)): ?>
                    <table class="application-table">
                        <thead>
                            <tr>
                                <th>Staff Name</th>
                                <th>Leave Type</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Reason</th>
                                <th>Supporting Document</th>
                                <?php if ($status == 'pending'): ?>
                                    <th>Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($filtered_applications as $application): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($application['staff_name']); ?></td>
                                    <td><?php echo htmlspecialchars($application['leave_type']); ?></td>
                                    <td><?php echo htmlspecialchars($application['start_date']); ?></td>
                                    <td><?php echo htmlspecialchars($application['end_date']); ?></td>
                                    <td><?php echo htmlspecialchars($application['reason']); ?></td>
                                    <td>
                                        <?php if (!empty($application['supporting_document'])): ?>
                                            <a href="/LeaveSystem/uploads/<?php echo htmlspecialchars($application['supporting_document']); ?>" target="_blank">View Document</a>
                                        <?php else: ?>
                                            No document attached
                                        <?php endif; ?>
                                    </td>
                                    <?php if ($status == 'pending'): ?>
                                        <td>
                                            <form action="hod_review.php" method="POST">
                                                <input type="hidden" name="leave_id" value="<?php echo $application['application_id']; ?>">
                                                <div class="action-btns">
                                                    <button type="submit" name="status" value="approved" class="action-btn approve-btn">Approve</button>
                                                    <button type="submit" name="status" value="rejected" class="action-btn reject-btn">Reject</button>
                                                </div>
                                            </form>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No <?php echo $status; ?> applications.</p>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Back to Home Button -->
    <a href="../Hod" class="home-button">Back to Dashboard</a>
</div>

<script>
    // JavaScript to handle status button clicks
    document.getElementById("pending-btn").onclick = function() {
        toggleStatusView('pending');
    };
    document.getElementById("approved-btn").onclick = function() {
        toggleStatusView('approved');
    };
    document.getElementById("rejected-btn").onclick = function() {
        toggleStatusView('rejected');
    };

    function toggleStatusView(status) {
        const sections = document.querySelectorAll('.status-section');
        sections.forEach(function(section) {
            section.style.display = 'none';
        });
        document.getElementById(status + '-applications').style.display = 'block';
    }

    // Set default view to Pending
    toggleStatusView('pending');
</script>

</body>
</html>