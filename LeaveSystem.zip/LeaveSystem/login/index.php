<?php
// Include the database connection file
include 'db_connection.php';

// Initialize error message
$error_message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $staff_id = $_POST['staff_id'];
    $password = $_POST['password'];

    // Query to check user credentials and fetch role
    $query = "SELECT staff.staff_id, staff.name, staff.password, roles.role_name, roles.level_id
              FROM staff
              JOIN roles ON staff.level_id = roles.level_id
              WHERE staff.staff_id = ? AND staff.password = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $staff_id, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        session_start();
        $_SESSION['staff_id'] = $row['staff_id'];
        $_SESSION['name'] = $row['name'];
        $_SESSION['role'] = $row['role_name'];
        $_SESSION['level_id'] = $row['level_id'];

        // Redirect based on role level
        if ($row['level_id'] == 1) {
            header("Location: ../Staff");
        } elseif ($row['level_id'] == 2) {
            header("Location: ../Hod");
        } elseif ($row['level_id'] == 3) {
            header("Location: ../HR");
        } else {
            $error_message = "Invalid role assigned!";
        }
    } else {
        // Set error message for invalid credentials
        $error_message = "Invalid Staff ID or Password.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: Arial, sans-serif;
             background: url('https://media.penang360.my/file/penang360/hotels/jpg-cover-hompton-by-the-beach-penang.jpg');
			background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: rgba(0, 0, 0, 0.7); /* Black with 70% transparency */
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            padding: 30px;
            width: 400px;
            display: flex;
            flex-direction: column;
        }
        h1 {
            color: white;
            text-align: center;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: white;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .login-btn {
            width: 100%;
            padding: 10px;
            background-color: #4285F4;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }
        .login-btn:hover {
            background-color: #357ae8;
        }
        .error-message {
            color: yellow;
            font-size: 14px;
            margin-top: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Login</h1>
        <!-- Display error message if exists -->
        <?php if ($error_message): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <div class="form-group">
                <label for="staff_id">Staff ID</label>
                <input type="text" id="staff_id" name="staff_id" placeholder="Enter your Staff ID" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Enter your Password" required>
            </div>
            <button type="submit" class="login-btn">Login</button>
        </form>
    </div>
</body>
</html>

